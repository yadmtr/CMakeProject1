#include <QtWidgets/QApplication>
#include <sm/vvec>
#include <mplot/qt/viswidget.h>
#include <mplot/GraphVisual.h>

// Build a widget based mplot app
int main (int argc, char **argv)
{
    QApplication app(argc, argv);

    // Create widget. The GL version to be used is set inside viswidget. It's accessible as
    // mplot::qt::gl_version.
    mplot::qt::viswidget widget;
    // Calling show ensures initializeGL() method gets called. The alternative to
    // calling show() at the start of the main() function, is to set viswidget's
    // buildmodels callback (see app2).
    widget.show();

    // We can now add VisualModels to the Visual inside the Widget. Create a GraphVisual
    // object (obtaining a unique_ptr to the object) with a spatial offset within the
    // scene of 0,0,0
    auto gv = std::make_unique<mplot::GraphVisual<double, mplot::qt::gl_version>> (sm::vec<float>({0,0,0}));
    // This mandatory line of boilerplate code sets the parent pointer in GraphVisual and binds some functions
    widget.v.bindmodel (gv);
    // Allow 3D
    gv->twodimensional (false);
    // Data for the x axis. A vvec is like std::vector, but with built-in maths methods
    sm::vvec<double> x;
    // This works like numpy's linspace() (the 3 args are "start", "end" and "num"):
    x.linspace (-0.5, 0.8, 14);
    // Set a graph up of y = x^3
    gv->setdata (x, x.pow(3));
    // finalize() makes the GraphVisual compute the vertices of the OpenGL model
    gv->finalize();
    // Add the GraphVisual OpenGL model to the Visual scene, transferring ownership of the unique_ptr
    widget.v.addVisualModel (gv);

    return app.exec();
}
