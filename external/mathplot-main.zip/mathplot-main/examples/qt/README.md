This folder contains examples showing how to use morphologica to draw
OpenGL graphics in a Qt widget.
