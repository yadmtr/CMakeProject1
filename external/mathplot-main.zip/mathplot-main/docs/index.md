---
title: Welcome
layout: home
permalink: /
has_children: true
nav_order: 1
---
# Welcome to mathplot

This is a documentation and reference website for
mathplot, a library of header-only C++ code for data visualization  ([source code on Github](https://github.com/sebsjames/mathplot)).

You'll find tutorial content and class reference material for the library on these pages.

## Quick link to Reference

* [Visualization reference](/mathplot/ref/visual)
