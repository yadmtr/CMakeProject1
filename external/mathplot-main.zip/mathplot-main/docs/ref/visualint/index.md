---
title: Internal classes
parent: Reference
permalink: /ref/visualint/
nav_order: 4
layout: page
has_children: true
---
# Internal class reference

This section includes material that does *not* form part of the client
API to `morph::Visual` and other visualization classes. It will
help a developer who wants to understand the design of morphologica.
