---
title: Shaders
parent: Internal classes
grand_parent: Reference
permalink: /ref/visualint/shaders
layout: page
nav_order: 6
---

# Graphics shaders

Model, scene view and projection matrices, how these are passed to the shaders etc.