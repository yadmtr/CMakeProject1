---
title: morph::VisualTextModel
parent: Internal classes
grand_parent: Reference
permalink: /ref/visual/visualtextmodel
layout: page
nav_order: 2
---
```c++
#include <morph/VisualTextModel.h>
```
morph::VisualTextModel is an analogue to morph::VisualModel which is specialised for drawing text.