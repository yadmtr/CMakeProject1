---
title: morph::VisualBase
parent: Internal classes
grand_parent: Reference
permalink: /ref/visualint/visualbase
layout: page
nav_order: 8
---
`VisualBase` is the base class for `VisualOwnable` and `VisualOwnableMX`.

This class is a morphologica-internal class and there is never any
access of its methods in morphologica client code.
