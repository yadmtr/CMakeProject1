---
title: Reference
layout: page
permalink: /ref/
nav_order: 2
has_children: true
---
# mathplot reference

The ultimate reference source for the classes in mathplot is the
headers themselves. In many cases the headers are easy to read because
the code is not split up into header/implementation.

*These* reference pages are hand-written and should provide a
quick-to-browse summary of the details of each class.