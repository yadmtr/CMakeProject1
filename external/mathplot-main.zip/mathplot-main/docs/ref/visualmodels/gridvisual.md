---
title: morph::GridVisual
parent: VisualModel classes
grand_parent: Reference
permalink: /ref/visualmodels/gridvisual
layout: page
nav_order: 12
---
```c++
#include <morph/GridVisual.h>
```

# Visualizing a `morph::Grid`

`morph::GridVisual` is a class that draws a grid of rectangular elements.