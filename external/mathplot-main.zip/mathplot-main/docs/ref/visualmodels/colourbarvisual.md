---
title: morph::ColourBarVisual
parent: VisualModel classes
grand_parent: Reference
permalink: /ref/visualmodels/colourbarvisual
layout: page
nav_order: 12
---
```c++
#include <morph/ColourBarVisual.h>
```

# Colour bars

`morph::ColourBarVisual` is a class that draws scale bars, to indicate the values of colours in a visualization.