---
title: morph::HexGridVisual
parent: VisualModel classes
grand_parent: Reference
permalink: /ref/visualmodels/hexgridvisual
layout: page
nav_order: 16
---
```c++
#include <morph/HexGridVisual.h>
```

# Hexagonal Grids

`morph::HexGridVisual` is a class that draws hexagonal grids.