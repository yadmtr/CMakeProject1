---
title: morph::TxtVisual
parent: VisualModel classes
grand_parent: Reference
permalink: /ref/visualmodels/txtvisual
layout: page
nav_order: 18
---
```c++
#include <morph/TxtVisual.h>
```

# A `VisualModel` for text

`morph::TxtVisual` is a class for displaying only text.