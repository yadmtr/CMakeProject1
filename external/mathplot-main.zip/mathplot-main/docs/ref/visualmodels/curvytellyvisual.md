---
title: morph::CurvyTellyVisual
parent: VisualModel classes
grand_parent: Reference
permalink: /ref/visualmodels/curvytellyvisual
layout: page
nav_order: 14
---
```c++
#include <morph/CurvyTellyVisual.h>
```

# CurvyTellyVisual: A curved grid
