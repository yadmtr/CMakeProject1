---
title: morph::QuiverVisual
parent: VisualModel classes
grand_parent: Reference
permalink: /ref/visualmodels/quivervisual
layout: page
nav_order: 20
---
```c++
#include <morph/QuiverVisual.h>
```

# Quiver plots

`morph::QuiverVisual` is a class for drawing quiver plots.