---
title: morph::ScatterVisual
parent: VisualModel classes
grand_parent: Reference
permalink: /ref/visualmodels/scattervisual
layout: page
nav_order: 12
---
```c++
#include <morph/ScatterVisual.h>
```

# Scatter plots

`morph::ScatterVisual` is a class for drawing 3D scatter plots.