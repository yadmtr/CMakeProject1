./build/buildtools/Debug/incbin.exe mplot/VisualFaceMX.h -p vf_ -o mplot/fonts/verafonts.h
